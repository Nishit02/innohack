import { NextRequest, NextResponse } from 'next/server';
import { addProject, filterProjects } from '@/lib/projectsStore';

// GET - Fetch all projects (public)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const featured = searchParams.get('featured');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '12');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');

    // Use global store with filters
    const result = filterProjects({
      category,
      featured: featured === 'true' ? true : undefined,
      search,
      minPrice: minPrice ? parseFloat(minPrice) : undefined,
      maxPrice: maxPrice ? parseFloat(maxPrice) : undefined,
      page,
      limit
    });

    return NextResponse.json({
      success: true,
      projects: result.projects,
      pagination: result.pagination
    });

  } catch (error) {
    console.error('Fetch projects error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch projects' },
      { status: 500 }
    );
  }
}

// POST - Create new project (admin only)
export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.split(' ')[1];
    
    if (!token) {
      return NextResponse.json(
        { error: 'No token provided' },
        { status: 401 }
      );
    }

    // Add project to global store
    const projectData = await request.json();
    const newProject = addProject(projectData);
    
    return NextResponse.json({
      success: true,
      project: newProject
    }, { status: 201 });

  } catch (error: unknown) {
    console.error('Create project error:', error);
    
    return NextResponse.json(
      { error: 'Failed to create project' },
      { status: 500 }
    );
  }
}
