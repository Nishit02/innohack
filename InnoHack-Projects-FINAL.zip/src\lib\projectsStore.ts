// Global projects store for real-time updates
import { mockProjects } from './mockData';

// In-memory store that persists during the session
const projectsStore = [...mockProjects];

export interface Project {
  _id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  stock: number;
  featured: boolean;
  createdAt: string;
  updatedAt?: string;
}

// Get all projects
export function getAllProjects(): Project[] {
  return projectsStore;
}

// Get project by ID
export function getProjectById(id: string): Project | undefined {
  return projectsStore.find(p => p._id === id);
}

// Add new project
export function addProject(projectData: Omit<Project, '_id' | 'createdAt' | 'updatedAt'>): Project {
  const newProject: Project = {
    ...projectData,
    _id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  projectsStore.push(newProject);
  return newProject;
}

// Update project
export function updateProject(id: string, projectData: Partial<Project>): Project | null {
  const index = projectsStore.findIndex(p => p._id === id);
  
  if (index === -1) {
    return null;
  }
  
  projectsStore[index] = {
    ...projectsStore[index],
    ...projectData,
    _id: id, // Ensure ID doesn't change
    updatedAt: new Date().toISOString()
  };
  
  return projectsStore[index];
}

// Delete project
export function deleteProject(id: string): boolean {
  const index = projectsStore.findIndex(p => p._id === id);
  
  if (index === -1) {
    return false;
  }
  
  projectsStore.splice(index, 1);
  return true;
}

// Filter projects
export function filterProjects(filters: {
  category?: string;
  featured?: boolean;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  page?: number;
  limit?: number;
}): { projects: Project[]; total: number; pagination: { page: number; limit: number; total: number; pages: number } } {
  let filteredProjects = [...projectsStore];

  // Apply filters
  if (filters.category && filters.category !== 'all') {
    filteredProjects = filteredProjects.filter(p => p.category === filters.category);
  }

  if (filters.featured === true) {
    filteredProjects = filteredProjects.filter(p => p.featured);
  }

  if (filters.search) {
    const searchLower = filters.search.toLowerCase();
    filteredProjects = filteredProjects.filter(p => 
      p.title.toLowerCase().includes(searchLower) ||
      p.description.toLowerCase().includes(searchLower)
    );
  }

  if (filters.minPrice !== undefined) {
    filteredProjects = filteredProjects.filter(p => p.price >= filters.minPrice!);
  }

  if (filters.maxPrice !== undefined) {
    filteredProjects = filteredProjects.filter(p => p.price <= filters.maxPrice!);
  }

  const total = filteredProjects.length;
  const page = filters.page || 1;
  const limit = filters.limit || 12;
  const skip = (page - 1) * limit;
  
  const paginatedProjects = filteredProjects.slice(skip, skip + limit);

  return {
    projects: paginatedProjects,
    total,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    }
  };
}
