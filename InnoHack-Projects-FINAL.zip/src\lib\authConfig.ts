// Secure admin authentication configuration
import bcrypt from 'bcryptjs';

// Admin credentials from environment variables
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH || '$2b$12$ek91m4QbEddg9EVHMlfzLOE919630seMB9lhDH.jeuHoP.LJJT8jm'; // Default: admin123
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@innohack.com';

// Rate limiting configuration
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME = 15 * 60 * 1000; // 15 minutes

// Store failed login attempts (in production, use Redis or database)
const failedAttempts = new Map<string, { count: number; lastAttempt: number }>();

export interface AdminUser {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'super-admin';
  isActive: boolean;
  lastLogin?: Date;
}

export async function verifyAdminCredentials(username: string, password: string): Promise<AdminUser | null> {
  // Check rate limiting
  if (isAccountLocked(username)) {
    throw new Error('Account temporarily locked due to too many failed attempts. Please try again later.');
  }

  // Verify username
  if (username !== ADMIN_USERNAME) {
    recordFailedAttempt(username);
    return null;
  }

  // Verify password strictly with bcrypt (production)
  const isValidPassword = await bcrypt.compare(password, ADMIN_PASSWORD_HASH);
  
  if (!isValidPassword) {
    recordFailedAttempt(username);
    return null;
  }

  // Clear failed attempts on successful login
  failedAttempts.delete(username);

  return {
    id: 'admin-001',
    username: ADMIN_USERNAME,
    email: ADMIN_EMAIL,
    role: 'admin',
    isActive: true,
    lastLogin: new Date()
  };
}

function recordFailedAttempt(username: string): void {
  const now = Date.now();
  const attempts = failedAttempts.get(username) || { count: 0, lastAttempt: 0 };
  
  // Reset count if enough time has passed
  if (now - attempts.lastAttempt > LOCKOUT_TIME) {
    attempts.count = 0;
  }
  
  attempts.count++;
  attempts.lastAttempt = now;
  
  failedAttempts.set(username, attempts);
}

function isAccountLocked(username: string): boolean {
  const attempts = failedAttempts.get(username);
  if (!attempts) return false;
  
  const now = Date.now();
  
  // Reset if lockout time has passed
  if (now - attempts.lastAttempt > LOCKOUT_TIME) {
    failedAttempts.delete(username);
    return false;
  }
  
  return attempts.count >= MAX_LOGIN_ATTEMPTS;
}

export function getRemainingLockoutTime(username: string): number {
  const attempts = failedAttempts.get(username);
  if (!attempts) return 0;
  
  const now = Date.now();
  const timeSinceLastAttempt = now - attempts.lastAttempt;
  
  if (timeSinceLastAttempt >= LOCKOUT_TIME) {
    failedAttempts.delete(username);
    return 0;
  }
  
  return Math.ceil((LOCKOUT_TIME - timeSinceLastAttempt) / 1000);
}

// Generate password hash for setup (run this once to get the hash)
export async function generatePasswordHash(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}
