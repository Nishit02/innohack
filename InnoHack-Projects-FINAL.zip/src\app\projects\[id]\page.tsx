'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { useParams } from 'next/navigation';

interface Project {
  _id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  featured: boolean;
  stock: number;
  createdAt: string;
}

export default function ProjectDetailsPage() {
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const params = useParams();

  useEffect(() => {
    if (params.id) {
      fetchProject(params.id as string);
    }
  }, [params.id]);

  const fetchProject = async (id: string) => {
    try {
      const response = await fetch(`/api/projects/${id}`);
      const data = await response.json();
      
      if (data.success) {
        setProject(data.project);
      } else {
        setError('Project not found');
      }
    } catch (error) {
      console.error('Error fetching project:', error);
      setError('Failed to load project');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-300">Loading project details...</p>
        </div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😞</div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {error || 'Project not found'}
          </h1>
          <Link href="/projects">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Back to Projects
            </motion.button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              InnoHack Projects
            </Link>
            <nav className="flex space-x-6">
              <Link href="/" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                Home
              </Link>
              <Link href="/projects" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                Projects
              </Link>
              <Link href="/contact" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-6xl mx-auto"
        >
          {/* Breadcrumb */}
          <nav className="mb-6">
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
              <Link href="/" className="hover:text-blue-600 dark:hover:text-blue-400">Home</Link>
              <span>›</span>
              <Link href="/projects" className="hover:text-blue-600 dark:hover:text-blue-400">Projects</Link>
              <span>›</span>
              <span className="text-gray-900 dark:text-white">{project.title}</span>
            </div>
          </nav>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Project Image */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden"
            >
              <div className="h-96 bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                <div className="text-8xl text-white">
                  {project.category === 'CSE Projects' ? '💻' : '🌐'}
                </div>
              </div>
            </motion.div>

            {/* Project Details */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="space-y-6"
            >
              {/* Title and Category */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                    {project.category}
                  </span>
                  {project.featured && (
                    <span className="text-xs bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full">
                      ⭐ Featured
                    </span>
                  )}
                </div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                  {project.title}
                </h1>
              </div>

              {/* Price */}
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg text-gray-600 dark:text-gray-300">Price</span>
                  <span className="text-3xl font-bold text-green-600 dark:text-green-400">
                    ₹{project.price.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Stock Status */}
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg text-gray-600 dark:text-gray-300">Availability</span>
                  <span className={`text-lg font-semibold ${
                    project.stock > 0 
                      ? 'text-green-600 dark:text-green-400' 
                      : 'text-red-600 dark:text-red-400'
                  }`}>
                    {project.stock > 0 ? `${project.stock} in stock` : 'Out of stock'}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                  Project Description
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Features */}
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                  What&apos;s Included
                </h3>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex items-center">
                    <span className="text-green-500 mr-2">✓</span>
                    Complete source code
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-500 mr-2">✓</span>
                    Detailed documentation
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-500 mr-2">✓</span>
                    Setup instructions
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-500 mr-2">✓</span>
                    Technical support
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-500 mr-2">✓</span>
                    Future updates
                  </li>
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="space-y-4">
                <motion.a
                  href={project.stock > 0 ? `https://wa.me/message/RXHU5XUNAYQ4G1?text=Hi! I want to purchase the project: ${project.title} for ₹${project.price.toLocaleString()}. Please provide payment details and delivery information.` : '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: project.stock > 0 ? 1.02 : 1 }}
                  whileTap={{ scale: project.stock > 0 ? 0.98 : 1 }}
                  className={`w-full py-4 rounded-lg font-semibold text-lg transition-colors text-center block ${
                    project.stock > 0
                      ? 'bg-green-600 text-white hover:bg-green-700'
                      : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                  }`}
                >
                  {project.stock > 0 ? '🛒 Purchase Project' : 'Out of Stock'}
                </motion.a>
                
                <div className="grid grid-cols-2 gap-4">
                  <motion.a
                    href={`https://wa.me/message/RXHU5XUNAYQ4G1?text=Hi! I'm interested in the project: ${project.title} (₹${project.price.toLocaleString()}). Can you provide more details?`}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="py-3 border-2 border-green-600 text-green-600 dark:text-green-400 rounded-lg font-semibold hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors text-center"
                  >
                    💬 Contact Us
                  </motion.a>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="py-3 border-2 border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 rounded-lg font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    📤 Share Project
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Additional Information */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-12 bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
          >
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Project Information
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Category</h4>
                <p className="text-gray-600 dark:text-gray-300">{project.category}</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Created</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  {new Date(project.createdAt).toLocaleDateString()}
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Status</h4>
                <p className="text-gray-600 dark:text-gray-300">
                  {project.featured ? 'Featured Project' : 'Regular Project'}
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Stock</h4>
                <p className="text-gray-600 dark:text-gray-300">{project.stock} units available</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
