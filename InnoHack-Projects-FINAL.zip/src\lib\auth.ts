import { NextRequest } from 'next/server';
import { verifyToken, extractTokenFromHeader } from './jwt';

export async function authenticateAdmin(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  const token = extractTokenFromHeader(authHeader || undefined);
  
  if (!token) {
    return { isAuthenticated: false, admin: null, error: 'No token provided' };
  }

  const payload = verifyToken(token);
  if (!payload) {
    return { isAuthenticated: false, admin: null, error: 'Invalid token' };
  }

  return { isAuthenticated: true, admin: payload, error: null };
}

export function requireAuth(handler: Function) {
  return async (request: NextRequest, ...args: any[]) => {
    const auth = await authenticateAdmin(request);
    
    if (!auth.isAuthenticated) {
      return new Response(
        JSON.stringify({ error: auth.error }),
        { 
          status: 401,
          headers: { 'Content-Type': 'application/json' }
        }
      );
    }

    return handler(request, auth.admin, ...args);
  };
}
