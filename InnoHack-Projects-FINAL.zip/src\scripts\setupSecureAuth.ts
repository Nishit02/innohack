import bcrypt from 'bcryptjs';
import crypto from 'crypto';

// This script helps set up secure admin authentication
console.log('🔐 InnoHack Projects - Secure Admin Setup');
console.log('==========================================\n');

// Generate secure JWT secret
const jwtSecret = crypto.randomBytes(64).toString('hex');
console.log('🔑 Generated JWT Secret:');
console.log(`JWT_SECRET=${jwtSecret}\n`);

// Generate password hash for 'admin123' (change this password!)
const defaultPassword = 'admin123';
const passwordHash = bcrypt.hashSync(defaultPassword, 12);
console.log('🔒 Generated Password Hash for "admin123":');
console.log(`ADMIN_PASSWORD_HASH=${passwordHash}\n`);

console.log('📝 Add these to your .env.local file:');
console.log('=====================================');
console.log('ADMIN_USERNAME=admin');
console.log(`ADMIN_PASSWORD_HASH=${passwordHash}`);
console.log('ADMIN_EMAIL=admin@innohack.com');
console.log(`JWT_SECRET=${jwtSecret}\n`);

console.log('⚠️  SECURITY RECOMMENDATIONS:');
console.log('============================');
console.log('1. Change the default password "admin123" to something strong');
console.log('2. Use a unique username instead of "admin"');
console.log('3. Keep your .env.local file secure and never commit it to git');
console.log('4. Use different credentials for production');
console.log('5. Enable HTTPS in production');
console.log('6. Consider implementing 2FA for additional security\n');

console.log('🛡️  Security Features Implemented:');
console.log('==================================');
console.log('✅ Password hashing with bcrypt (12 rounds)');
console.log('✅ Rate limiting (5 attempts, 15-minute lockout)');
console.log('✅ Secure JWT tokens with strong secrets');
console.log('✅ Environment variable configuration');
console.log('✅ Account lockout protection');
console.log('✅ Input validation and sanitization\n');

console.log('🚀 Your admin system is now secure!');
console.log('Default credentials: admin / admin123');
console.log('(Change these immediately in production!)');
