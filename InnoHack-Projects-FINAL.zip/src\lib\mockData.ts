// Mock data for demo purposes when MongoDB is not available
export const mockProjects = [
  {
    _id: '1',
    title: 'Smart Home IoT System',
    description: 'Complete smart home automation system with sensors, actuators, and mobile app control. Features include temperature monitoring, lighting control, security system, and energy management.',
    price: 16999,
    category: 'IoT Projects',
    images: ['/placeholder-project.svg'],
    stock: 10,
    featured: true,
    createdAt: new Date().toISOString()
  },
  {
    _id: '2',
    title: 'Machine Learning Stock Predictor',
    description: 'Advanced ML model for stock price prediction using LSTM neural networks. Includes data preprocessing, model training, and web dashboard for visualization.',
    price: 12999,
    category: 'CSE Projects',
    images: ['/placeholder-project.svg'],
    stock: 15,
    featured: true,
    createdAt: new Date().toISOString()
  },
  {
    _id: '3',
    title: 'Arduino Weather Station',
    description: 'IoT weather monitoring station with multiple sensors (temperature, humidity, pressure, light). Includes data logging and web interface for real-time monitoring.',
    price: 7999,
    category: 'IoT Projects',
    images: ['/placeholder-project.svg'],
    stock: 20,
    featured: false,
    createdAt: new Date().toISOString()
  },
  {
    _id: '4',
    title: 'E-commerce Web Application',
    description: 'Full-stack e-commerce platform built with React, Node.js, and MongoDB. Features include user authentication, payment integration, admin dashboard, and responsive design.',
    price: 15999,
    category: 'CSE Projects',
    images: ['/placeholder-project.svg'],
    stock: 12,
    featured: true,
    createdAt: new Date().toISOString()
  },
  {
    _id: '5',
    title: 'Raspberry Pi Security Camera',
    description: 'DIY security camera system using Raspberry Pi with motion detection, night vision, and cloud storage. Includes mobile app for remote monitoring.',
    price: 11999,
    category: 'IoT Projects',
    images: ['/placeholder-project.svg'],
    stock: 8,
    featured: false,
    createdAt: new Date().toISOString()
  },
  {
    _id: '6',
    title: 'Blockchain Voting System',
    description: 'Secure voting system built on blockchain technology. Features include voter authentication, transparent vote counting, and immutable records.',
    price: 21999,
    category: 'CSE Projects',
    images: ['/placeholder-project.svg'],
    stock: 5,
    featured: true,
    createdAt: new Date().toISOString()
  }
];

export const mockOrders = [
  {
    _id: '1',
    totalAmount: 29998,
    status: 'paid',
    items: [
      {
        title: 'Smart Home IoT System',
        quantity: 1,
        price: 16999
      },
      {
        title: 'Machine Learning Stock Predictor',
        quantity: 1,
        price: 12999
      }
    ],
    createdAt: new Date().toISOString()
  },
  {
    _id: '2',
    totalAmount: 16999,
    status: 'pending',
    items: [
      {
        title: 'Smart Home IoT System',
        quantity: 1,
        price: 16999
      }
    ],
    createdAt: new Date().toISOString()
  }
];
