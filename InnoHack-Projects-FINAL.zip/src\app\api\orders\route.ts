import { NextRequest, NextResponse } from 'next/server';
import { mockOrders } from '@/lib/mockData';

// GET - Fetch all orders (admin only)
export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.split(' ')[1];
    
    if (!token) {
      return NextResponse.json(
        { error: 'No token provided' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');

    // Use mock data for demo
    let orders = mockOrders;
    let total = mockOrders.length;

    // Apply filters to mock data
    let filteredOrders = mockOrders;
    if (status && status !== 'all') {
      filteredOrders = filteredOrders.filter(o => o.status === status);
    }

    total = filteredOrders.length;
    const skip = (page - 1) * limit;
    orders = filteredOrders.slice(skip, skip + limit);

    return NextResponse.json({
      success: true,
      orders,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Fetch orders error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch orders' },
      { status: 500 }
    );
  }
}

// POST - Create new order (public)
export async function POST(request: NextRequest) {
  try {
    const { items, customerInfo, shippingAddress, paymentMethod } = await request.json();

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: 'Order items are required' },
        { status: 400 }
      );
    }

    // For demo purposes, just return success
    const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const order = {
      _id: Date.now().toString(),
      orderId,
      items,
      customerInfo,
      shippingAddress,
      totalAmount: items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      paymentMethod,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    return NextResponse.json({
      success: true,
      order
    });

  } catch (error) {
    console.error('Create order error:', error);
    return NextResponse.json(
      { error: 'Failed to create order' },
      { status: 500 }
    );
  }
}
