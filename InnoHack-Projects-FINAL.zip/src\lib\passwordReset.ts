import crypto from 'crypto';

type ResetRecord = {
  token: string;
  username: string;
  expiresAt: number;
};

// In-memory store (replace with DB/Redis in production)
const usernameToReset: Map<string, ResetRecord> = new Map();
const tokenToReset: Map<string, ResetRecord> = new Map();

const RESET_TTL_MS = 15 * 60 * 1000; // 15 minutes

export function createPasswordResetToken(username: string): ResetRecord {
  const token = crypto.randomBytes(24).toString('hex');
  const record: ResetRecord = {
    token,
    username,
    expiresAt: Date.now() + RESET_TTL_MS,
  };
  usernameToReset.set(username, record);
  tokenToReset.set(token, record);
  return record;
}

export function getResetRecordByToken(token: string): ResetRecord | null {
  const rec = tokenToReset.get(token);
  if (!rec) return null;
  if (Date.now() > rec.expiresAt) {
    // cleanup expired
    usernameToReset.delete(rec.username);
    tokenToReset.delete(token);
    return null;
  }
  return rec;
}

export function consumeResetToken(token: string): ResetRecord | null {
  const rec = getResetRecordByToken(token);
  if (!rec) return null;
  usernameToReset.delete(rec.username);
  tokenToReset.delete(token);
  return rec;
}

export function remainingTtlSeconds(token: string): number {
  const rec = tokenToReset.get(token);
  if (!rec) return 0;
  const remaining = Math.max(0, rec.expiresAt - Date.now());
  return Math.ceil(remaining / 1000);
}


