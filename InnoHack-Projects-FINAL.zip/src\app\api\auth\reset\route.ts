import { NextRequest, NextResponse } from 'next/server';
import { consumeResetToken } from '@/lib/passwordReset';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  try {
    const { token, newPassword } = await req.json();
    if (!token || !newPassword || newPassword.length < 8) {
      return NextResponse.json({ error: 'Invalid input' }, { status: 400 });
    }

    const rec = consumeResetToken(token);
    if (!rec) {
      return NextResponse.json({ error: 'Invalid or expired token' }, { status: 400 });
    }

    // Update environment-backed password hash (in-memory only for demo)
    const hash = await bcrypt.hash(newPassword, 12);
    process.env.ADMIN_PASSWORD_HASH = hash;

    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json({ error: 'Failed to reset password' }, { status: 500 });
  }
}


