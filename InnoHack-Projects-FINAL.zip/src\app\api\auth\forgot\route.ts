import { NextRequest, NextResponse } from 'next/server';
import { createPasswordResetToken } from '@/lib/passwordReset';

export async function POST(req: NextRequest) {
  try {
    const { username } = await req.json();
    if (!username) {
      return NextResponse.json({ error: 'Username required' }, { status: 400 });
    }

    // Always generate for the single admin account
    const { token } = createPasswordResetToken(username);

    // Send email (stubbed): force-send to innohack9@gmail.com
    const email = process.env.CONTACT_EMAIL || 'innohack9@gmail.com';
    console.log(`Password reset token for ${username}: ${token} (sent to ${email})`);

    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json({ error: 'Failed to start reset' }, { status: 500 });
  }
}


