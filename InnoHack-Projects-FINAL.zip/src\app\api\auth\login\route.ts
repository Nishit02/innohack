import { NextRequest, NextResponse } from 'next/server';
import { generateToken } from '@/lib/jwt';
import { verifyAdminCredentials, getRemainingLockoutTime } from '@/lib/authConfig';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 }
      );
    }

    // Check for account lockout
    const lockoutTime = getRemainingLockoutTime(username);
    if (lockoutTime > 0) {
      return NextResponse.json(
        { 
          error: `Account temporarily locked. Please try again in ${Math.ceil(lockoutTime / 60)} minutes.`,
          lockoutTime 
        },
        { status: 429 }
      );
    }

    try {
      // Verify admin credentials
      const admin = await verifyAdminCredentials(username, password);
      
      if (!admin) {
        return NextResponse.json(
          { error: 'Invalid credentials' },
          { status: 401 }
        );
      }

      // Generate JWT token
      const token = generateToken({
        adminId: admin.id,
        username: admin.username,
        role: admin.role
      });

      return NextResponse.json({
        success: true,
        token,
        admin: {
          id: admin.id,
          username: admin.username,
          email: admin.email,
          role: admin.role,
          lastLogin: admin.lastLogin
        }
      });

    } catch (error: unknown) {
      if (error instanceof Error && error.message.includes('Account temporarily locked')) {
        return NextResponse.json(
          { error: error.message },
          { status: 429 }
        );
      }
      throw error;
    }

  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
